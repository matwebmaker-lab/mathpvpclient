package no.matheo.pvpclient;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Lunar-inspirert innstillingsmeny: mørk panel, kategorier, flere valg.
 */
public class PvpClientScreen extends class_437 {

	private static final int SIDEBAR_WIDTH = 120;
	private static final int PANEL_PADDING = 16;
	private static final int ACCENT_COLOR = 0xFF_2D_D4_9E; // Lunar-lignende teal
	private static final int PANEL_BG = 0xE0_1A_1A_1A;
	private static final int SIDEBAR_BG = 0xF0_12_12_12;

	private static final class_2960 LOGO = class_2960.method_60655("matheo-pvp-client", "textures/gui/logo.png");

	private static final class_2561 TITLE = class_2561.method_43471("menu.matheo_pvp_client.title");
	private static final class_2561 CAT_VISUALS = class_2561.method_43471("menu.matheo_pvp_client.category.visuals");
	private static final class_2561 CAT_HUD = class_2561.method_43471("menu.matheo_pvp_client.category.hud");
	private static final class_2561 AUTO_SPRINT_LABEL = class_2561.method_43471("menu.matheo_pvp_client.auto_sprint");
	private static final class_2561 FULLBRIGHT_LABEL = class_2561.method_43471("menu.matheo_pvp_client.fullbright");
	private static final class_2561 TNT_TIMER_LABEL = class_2561.method_43471("menu.matheo_pvp_client.tnt_timer");
	private static final class_2561 REACH_HITBOX_LABEL = class_2561.method_43471("menu.matheo_pvp_client.reach_hitbox");
	private static final class_2561 FPS_LABEL = class_2561.method_43471("menu.matheo_pvp_client.fps");
	private static final class_2561 COORDS_LABEL = class_2561.method_43471("menu.matheo_pvp_client.coords");
	private static final class_2561 ARMOR_LABEL = class_2561.method_43471("menu.matheo_pvp_client.armor");

	public PvpClientScreen() {
		super(TITLE);
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		int panelWidth = this.field_22789 - SIDEBAR_WIDTH - PANEL_PADDING * 2;
		int buttonWidth = class_3532.method_15340(panelWidth - PANEL_PADDING * 2, 180, 260);
		int centerX = SIDEBAR_WIDTH + (this.field_22789 - SIDEBAR_WIDTH) / 2;
		int spacing = 26;
		int y = 56;

		// Visuals (Auto Sprint, Fullbright, …)
		this.method_37063(
				class_4185.method_46430(getAutoSprintButtonText(), b -> {
					ModConfig.toggleAutoSprint();
					b.method_25355(getAutoSprintButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());
		y += spacing;
		this.method_37063(
				class_4185.method_46430(getFullbrightButtonText(), b -> {
					ModConfig.toggleFullbright();
					b.method_25355(getFullbrightButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());
		y += spacing;
		this.method_37063(
				class_4185.method_46430(getTntTimerButtonText(), b -> {
					ModConfig.toggleTntTimer();
					b.method_25355(getTntTimerButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());
		y += spacing;
		this.method_37063(
				class_4185.method_46430(getReachHitboxButtonText(), b -> {
					ModConfig.toggleReachHitbox();
					b.method_25355(getReachHitboxButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());
		y += spacing + 20;

		// HUD
		this.method_37063(
				class_4185.method_46430(getFpsButtonText(), b -> {
					ModConfig.toggleShowFps();
					b.method_25355(getFpsButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());
		y += spacing;
		this.method_37063(
				class_4185.method_46430(getCoordsButtonText(), b -> {
					ModConfig.toggleShowCoords();
					b.method_25355(getCoordsButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());
		y += spacing;
		this.method_37063(
				class_4185.method_46430(getArmorButtonText(), b -> {
					ModConfig.toggleShowArmor();
					b.method_25355(getArmorButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, 20).method_46431());

		// Lukk
		this.method_37063(
				class_4185.method_46430(class_2561.method_43471("menu.matheo_pvp_client.close"), b -> {
					if (field_22787 != null) field_22787.method_1507(null);
				}).method_46434(centerX - buttonWidth / 2, this.field_22790 - 32, buttonWidth, 20).method_46431());
	}

	private static class_2561 getAutoSprintButtonText() {
		return toggleText(AUTO_SPRINT_LABEL, ModConfig.isAutoSprint());
	}

	private static class_2561 getFullbrightButtonText() {
		return toggleText(FULLBRIGHT_LABEL, ModConfig.isFullbright());
	}

	private static class_2561 getTntTimerButtonText() {
		return toggleText(TNT_TIMER_LABEL, ModConfig.isTntTimer());
	}

	private static class_2561 getReachHitboxButtonText() {
		return toggleText(REACH_HITBOX_LABEL, ModConfig.isReachHitbox());
	}

	private static class_2561 getFpsButtonText() {
		return toggleText(FPS_LABEL, ModConfig.isShowFps());
	}

	private static class_2561 getCoordsButtonText() {
		return toggleText(COORDS_LABEL, ModConfig.isShowCoords());
	}

	private static class_2561 getArmorButtonText() {
		return toggleText(ARMOR_LABEL, ModConfig.isShowArmor());
	}

	private static class_2561 toggleText(class_2561 label, boolean on) {
		return label.method_27661().method_27693(": ")
				.method_10852(class_2561.method_43471(on ? "menu.matheo_pvp_client.on" : "menu.matheo_pvp_client.off"));
	}

	@Override
	public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
		// Mørk bakgrunn uten blur (unngår "Can only blur once per frame")
		context.method_25294(0, 0, this.field_22789, this.field_22790, 0xC0_08_08_0C);
		// Sidebar – Lunar-lignende mørk stripe
		context.method_25294(0, 0, SIDEBAR_WIDTH, this.field_22790, SIDEBAR_BG);
		// Vertikal accentlinje
		context.method_25294(SIDEBAR_WIDTH, 0, SIDEBAR_WIDTH + 2, this.field_22790, ACCENT_COLOR);
		// Hovedpanel (rundt innhold)
		int panelLeft = SIDEBAR_WIDTH + PANEL_PADDING;
		int panelTop = PANEL_PADDING * 2;
		int panelRight = this.field_22789 - PANEL_PADDING;
		int panelBottom = this.field_22790 - PANEL_PADDING;
		context.method_25294(panelLeft, panelTop, panelRight, panelBottom, PANEL_BG);
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);

		// Logo øverst i hovedpanelet (sentrert)
		int logoSize = 100;
		int logoX = SIDEBAR_WIDTH + (this.field_22789 - SIDEBAR_WIDTH) / 2 - logoSize / 2;
		int logoY = 10;
		context.method_70845(LOGO, logoX, logoY, logoX + logoSize, logoY + logoSize, 0f, 1f, 0f, 1f);

		// Tittel i sidebar (under logo-område i layout)
		context.method_51439(this.field_22793, this.method_25440(), 16, 20, 0xFFFFFF, false);
		// Kategorier i sidebar
		context.method_51439(this.field_22793, CAT_VISUALS, 16, 48, ACCENT_COLOR, false);
		context.method_51439(this.field_22793, CAT_HUD, 16, 168, ACCENT_COLOR, false);

		// Seksjonsoverskrifter over innhold
		int cx = SIDEBAR_WIDTH + (this.field_22789 - SIDEBAR_WIDTH) / 2;
		context.method_27534(this.field_22793, CAT_VISUALS, cx, 40, 0xAAAAAA);
		context.method_27534(this.field_22793, CAT_HUD, cx, 184, 0xAAAAAA);
	}
}

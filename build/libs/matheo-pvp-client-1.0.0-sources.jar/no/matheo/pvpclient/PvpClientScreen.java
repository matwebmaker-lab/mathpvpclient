package no.matheo.pvpclient;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PvpClientScreen extends class_437 {

	private static final class_2561 TITLE = class_2561.method_43471("menu.matheo_pvp_client.title");
	private static final class_2561 FULLBRIGHT_LABEL = class_2561.method_43471("menu.matheo_pvp_client.fullbright");
	private static final class_2561 TNT_TIMER_LABEL = class_2561.method_43471("menu.matheo_pvp_client.tnt_timer");
	private static final class_2561 REACH_HITBOX_LABEL = class_2561.method_43471("menu.matheo_pvp_client.reach_hitbox");

	public PvpClientScreen() {
		super(TITLE);
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		int centerX = this.field_22789 / 2;
		int buttonWidth = 200;
		int buttonHeight = 20;
		int y = 40;
		int spacing = 28;

		// Fullbright av/på
		this.method_37063(
				class_4185.method_46430(getFullbrightButtonText(), button -> {
					ModConfig.toggleFullbright();
					button.method_25355(getFullbrightButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight).method_46431());
		y += spacing;

		// TNT-timer av/på
		this.method_37063(
				class_4185.method_46430(getTntTimerButtonText(), button -> {
					ModConfig.toggleTntTimer();
					button.method_25355(getTntTimerButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight).method_46431());
		y += spacing;

		// Rød hitbox innenfor slåavstand
		this.method_37063(
				class_4185.method_46430(getReachHitboxButtonText(), button -> {
					ModConfig.toggleReachHitbox();
					button.method_25355(getReachHitboxButtonText());
				}).method_46434(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight).method_46431());
		y += spacing;

		// Lukk-knapp
		this.method_37063(
				class_4185.method_46430(class_2561.method_43471("menu.matheo_pvp_client.close"), b -> {
					if (field_22787 != null) field_22787.method_1507(null);
				}).method_46434(centerX - buttonWidth / 2, this.field_22790 - 28, buttonWidth, buttonHeight).method_46431());
	}

	private static class_2561 getFullbrightButtonText() {
		return FULLBRIGHT_LABEL.method_27661().method_27693(": ")
				.method_10852(ModConfig.isFullbright()
						? class_2561.method_43471("menu.matheo_pvp_client.on")
						: class_2561.method_43471("menu.matheo_pvp_client.off"));
	}

	private static class_2561 getTntTimerButtonText() {
		return TNT_TIMER_LABEL.method_27661().method_27693(": ")
				.method_10852(ModConfig.isTntTimer()
						? class_2561.method_43471("menu.matheo_pvp_client.on")
						: class_2561.method_43471("menu.matheo_pvp_client.off"));
	}

	private static class_2561 getReachHitboxButtonText() {
		return REACH_HITBOX_LABEL.method_27661().method_27693(": ")
				.method_10852(ModConfig.isReachHitbox()
						? class_2561.method_43471("menu.matheo_pvp_client.on")
						: class_2561.method_43471("menu.matheo_pvp_client.off"));
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);
		context.method_27534(this.field_22793, this.method_25440(), this.field_22789 / 2, 16, 0xFFFFFF);
	}
}

package no.matheo.pvpclient.mixin;

import net.minecraft.class_315;
import net.minecraft.class_757;
import no.matheo.pvpclient.ModConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_757.class)
public class GameRendererMixin {

	@Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/GameOptions;getGamma()D"))
	private double fullbrightGamma(class_315 options) {
		return ModConfig.isFullbright() ? 16.0 : options.method_42473().method_41753();
	}
}

package no.matheo.pvpclient;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_1299;
import net.minecraft.class_1541;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9779;
import java.util.List;

/**
 * HUD-tegning for 1.21: TNT-timer, FPS, koordinater.
 * Bruker HudElementRegistry (HudRenderCallback fungerer ikke lenger i 1.21).
 */
public class PvpClientHud {

	private static final class_2960 HUD_ID = class_2960.method_60655("matheo-pvp-client", "overlay");
	private static final int RANGE = 64;
	private static final int X = 6;
	private static final int LINE_HEIGHT = 10;
	private static final int TNT_COLOR = 0xFFDD00;
	private static final int TEXT_COLOR = 0xFFFFFF;

	public static void register() {
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.MISC_OVERLAYS,
				HUD_ID,
				PvpClientHud::render
		);
	}

	private static void render(class_332 context, class_9779 tickCounter) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1687 == null) return;

		int y = 6;

		// FPS
		if (ModConfig.isShowFps()) {
			int fps = client.method_47599();
			context.method_51439(client.field_1772, class_2561.method_43470("FPS: " + fps), X, y, TEXT_COLOR, true);
			y += LINE_HEIGHT;
		}

		// Koordinater
		if (ModConfig.isShowCoords()) {
			int px = class_3532.method_15357(client.field_1724.method_23317());
			int py = class_3532.method_15357(client.field_1724.method_23318());
			int pz = class_3532.method_15357(client.field_1724.method_23321());
			context.method_51439(client.field_1772, class_2561.method_43470(String.format("XYZ: %d %d %d", px, py, pz)), X, y, TEXT_COLOR, true);
			y += LINE_HEIGHT;
		}

		// TNT-timer
		if (ModConfig.isTntTimer()) {
			class_238 box = client.field_1724.method_5829().method_1014(RANGE);
			List<class_1541> tntList = client.field_1687.method_18023(class_1299.field_6063, box, e -> true);
			for (class_1541 tnt : tntList) {
				double seconds = tnt.method_6969() / 20.0;
				context.method_51439(client.field_1772, class_2561.method_43470(String.format("TNT: %.1fs", seconds)), X, y, TNT_COLOR, true);
				y += LINE_HEIGHT;
			}
		}
	}
}

package no.matheo.pvpclient;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

/**
 * Viser rød outline (glow) på spillere innenfor slåavstand.
 * Bruker vanlig entity glow i stedet for custom world rendering (Fabric 1.21.11).
 */
public class ReachHitboxRenderer {

	private static final double MELEE_REACH = 3.0;

	public static void register() {
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1687 == null || client.method_1560() == null) return;

			double reachSq = MELEE_REACH * MELEE_REACH;
			class_1297 camera = client.method_1560();
			boolean featureOn = ModConfig.isReachHitbox();

			for (class_1297 entity : client.field_1687.method_18112()) {
				if (!(entity instanceof class_1657) || entity == camera || !entity.method_5805()) continue;
				boolean inReach = featureOn && entity.method_5858(camera) <= reachSq;
				entity.method_5834(inReach);
			}
		});
	}
}

package no.matheo.pvpclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1299;
import net.minecraft.class_1541;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.util.List;

@SuppressWarnings("deprecation") // HudRenderCallback deprecated i 1.21; HudElementRegistry er erstatning
public class TntTimerRenderer {

	private static final int RANGE = 64;
	private static final int X = 6;
	private static final int Y_START = 6;
	private static final int LINE_HEIGHT = 10;
	private static final int COLOR = 0xFFDD00; // gul/oransje

	public static void register() {
		HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
			if (!ModConfig.isTntTimer()) return;

			class_310 client = class_310.method_1551();
			if (client.field_1687 == null || client.field_1724 == null) return;

			class_238 box = client.field_1724.method_5829().method_1014(RANGE);
			List<class_1541> tntList = client.field_1687.method_18023(
					class_1299.field_6063,
					box,
					e -> true
			);

			if (tntList.isEmpty()) return;

			int y = Y_START;
			for (class_1541 tnt : tntList) {
				double seconds = tnt.method_6969() / 20.0;
				String line = String.format("TNT: %.1fs", seconds);
				drawContext.method_51439(client.field_1772, class_2561.method_43470(line), X, y, COLOR, true);
				y += LINE_HEIGHT;
			}
		});
	}
}

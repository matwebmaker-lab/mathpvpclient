package no.matheo.pvpclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class MatheoPvpClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		KeyBindings.register();
		PvpClientHud.register(); // TNT-timer, FPS, koordinater (HudElementRegistry for 1.21)
		ReachHitboxRenderer.register();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1690 == null) return;

			// Fullbright: sett gamma høyt (uten mixin – 1.21.11)
			if (ModConfig.isFullbright()) {
				client.field_1690.method_42473().method_41748(16.0);
			} else {
				client.field_1690.method_42473().method_41748(1.0);
			}

			if (client.field_1724 == null) return;

			// Høyre Shift: åpne meny
			while (KeyBindings.OPEN_MENU.method_1436()) {
				client.method_1507(new PvpClientScreen());
			}

			// Auto sprint (når W holdes, ikke sneak/vann/item)
			if (ModConfig.isAutoSprint()) {
				boolean forward = client.field_1690.field_1894.method_1434();
				if (forward && !client.field_1724.method_5715()
						&& !client.field_1724.field_5976
						&& client.field_1724.method_24828()
						&& !client.field_1724.method_5799()
						&& !client.field_1724.method_6115()) {
					client.field_1724.method_5728(true);
				}
			}
		});
	}
}

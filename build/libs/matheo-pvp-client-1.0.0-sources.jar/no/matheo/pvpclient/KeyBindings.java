package no.matheo.pvpclient;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

	public static class_304 OPEN_MENU;

	public static void register() {
		OPEN_MENU = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.matheo_pvp_client.open_menu",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				class_304.class_11900.field_62556
		));
	}
}

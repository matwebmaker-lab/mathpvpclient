package no.matheo.pvpclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@SuppressWarnings("deprecation")
public class HudOverlayRenderer {

	private static final int FPS_X = 4;
	private static final int FPS_Y = 4;
	private static final int COORDS_X = 4;
	private static final int COORDS_Y = 14;
	private static final int COLOR = 0xFFFFFF;

	public static void register() {
		HudRenderCallback.EVENT.register((context, tickDelta) -> {
			class_310 client = class_310.method_1551();
			if (client.field_1724 == null) return;

			int y = 4;
			if (ModConfig.isShowFps()) {
				int fps = client.method_47599();
				context.method_51439(client.field_1772, class_2561.method_43470("FPS: " + fps), FPS_X, y, COLOR, true);
				y += 10;
			}
			if (ModConfig.isShowCoords()) {
				int x = class_3532.method_15357(client.field_1724.method_23317());
				int py = class_3532.method_15357(client.field_1724.method_23318());
				int z = class_3532.method_15357(client.field_1724.method_23321());
				context.method_51439(client.field_1772, class_2561.method_43470(String.format("XYZ: %d %d %d", x, py, z)), COORDS_X, y, COLOR, true);
			}
		});
	}
}
